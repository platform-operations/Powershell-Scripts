Configuration SecureVM
# Security Settings for VMs

{

    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullorEmpty()]
        [PSCredential]
        $Credential
    )
    Import-DscResource -ModuleName PSDesiredStateConfiguration, xRemoteDesktopAdmin, xNetworking
    Node "localhost"  {
        # create local user account
        User LocalUserAccount
        {
            Username = $Credential.UserName
            Password = $Credential
            Disabled = $false
            Ensure = "Present"
            FullName = "Local User Account"
            Description = "Local User Account"
            PasswordNeverExpires = $true
        }
		# Changes RDP port to 27901
		Registry ChangeRDPPort
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
			ValueName = "PortNumber"
			ValueData = "6cfd"
			ValueType = "Dword"
			Hex = $true
			Force = $true
		}

		# Enforces NLA for RDP
		xRemoteDesktopAdmin RemoteDesktopSettings 
        {
           Ensure = 'Present'
           UserAuthentication = 'Secure'
        }

		# Opens incoming port 27910 for RDP
        xFirewall NewRDPPort
        {
            Name = "Custom RDP Port"
            DisplayName = "Custom RDP Port"
            Ensure = "Present"
            Enabled = $true
            Action = "Allow"
            Profile = "Public"
            Direction = "InBound"
            RemotePort = "Any"
            LocalPort = "27901"
            Protocol = "TCP"
            Description = "Firewall rule for port 27901 RDP"
        }

		# Adjusts some local security settings for enforcing strong passwords
		Script PasswordHarden 
		{
			GetScript = { 
			}
			SetScript = { 
				secedit /export /cfg ${env:appdata}\secpol.cfg
				(get-content ${env:appdata}\secpol.cfg) | Foreach-Object {$_ -replace 'PasswordComplexity = 0', 'PasswordComplexity = 1'} | Out-File ${env:appdata}\secpol.cfg
				(get-content ${env:appdata}\secpol.cfg) | Foreach-Object {$_ -replace 'MinimumPasswordLength = .+$', 'MinimumPasswordLength = 14'} | Out-File ${env:appdata}\secpol.cfg
				secedit /configure /db c:\windows\security\local.sdb /cfg ${env:appdata}\secpol.cfg /areas SECURITYPOLICY
				Remove-Item -force ${env:appdata}\secpol.cfg -confirm:$false
			}
			TestScript = { 
				$false 
			}
		}

		# RDP hardening reg keys
		# Disables RDP client audio mapping
		Registry DisableRDPAudio
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
			ValueName = "fDisableCam"
			ValueData = "1"
			ValueType = "Dword"
			Force = $true
		}
		# Disables RDP client COM mapping
		Registry DisableRDPCOM
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
			ValueName = "fDisableCcm"
			ValueData = "1"
			ValueType = "Dword"
			Force = $true
		}
		# Disables RDP client drive mapping
		Registry DisableRDPDrives
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
			ValueName = "fDisableCdm"
			ValueData = "1"
			ValueType = "Dword"
			Force = $true
		}
		# Disables RDP client clipboard mapping
		Registry DisableRDPClipboard
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
			ValueName = "fDisableClip"
			ValueData = "1"
			ValueType = "Dword"
			Force = $true
		}
		# Disables RDP client printer mapping
		Registry DisableRDPPrinter
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
			ValueName = "fDisableCpm"
			ValueData = "1"
			ValueType = "Dword"
			Force = $true
		}
	}
}
